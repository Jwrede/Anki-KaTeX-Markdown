// @flow
import {_environments} from "./defineEnvironment";

const environments = _environments;

export default environments;

// All environment definitions should be imported below
import "./environments/array";
