/**
 * This is the webpack entry point for KaTeX. As ECMAScript doesn't support
 * CSS modules natively, a separate entry point is used.
 */
import './copy-tex.css';
import './copy-tex.js';
